export const environment = {
  production: true,
 // urlServicios : "assets/",
 urlServicios : "https://apinormal.casasmarket.pe/index.php/market/",
  imgPath : "../assets/imgs/"
};
